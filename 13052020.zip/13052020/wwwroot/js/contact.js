﻿$(function () {
    $("#navbarSupportedContent li ").parent().find('li').removeClass("active");
    //$("#navbarSupportedContent li ").parent().find('li').removeClass("active");

    $("#" + contactId).addClass("active");
});